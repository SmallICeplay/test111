<template>
  <div class="page flex-col">
    <div class="block_1 flex-col">
      <NavigationMenu
        @navigate="handleNavigation"
        @language-change="handleLanguageChange"
        @search-query="handleSearchQuery"
      />
      <div class="box_101 flex-col">
        <div class="section_61 flex-row justify-between">
          <div class="group_2 flex-col">
            <div class="box_3 flex-col">
              <div class="block_57 flex-row justify-between">
                <span class="paragraph_1">
                  做市商
                  <br />
                  招商计划
                </span>
                <div class="text-wrapper_7 flex-col justify-center"><span class="text_9">开启</span></div>
              </div>
              <div class="text-wrapper_8 flex-col"><span class="text_10">享受专有激励政策</span></div>
              <div class="text-wrapper_126 flex-row justify-between">
                <span class="text_11">申请发送邮件至</span>
                <span class="text_12">suopu&#64;mxccorp.com</span>
              </div>
            </div>
          </div>
          <div class="group_3 flex-col">
            <div class="box_5 flex-col">
              <div class="block_58 flex-row">
                <div class="text-wrapper_10 flex-col"><span class="text_13">20TH&nbsp;session</span></div>
                <span class="text_14">Kickstarter</span>
                <span class="text_15">BHO</span>
              </div>
              <div class="text-wrapper_127 flex-row">
                <span class="text_16">Vote&nbsp;for&nbsp;a&nbsp;listing,&nbsp;win&nbsp;free&nbsp;airdrops!</span>
              </div>
              <div class="text-wrapper_128 flex-row"><span class="text_17">Featured&nbsp;Project</span></div>
              <div class="text-wrapper_129 flex-row justify-between">
                <span class="text_18">BHO</span>
                <span class="text_19">888,888</span>
              </div>
            </div>
          </div>
          <div class="group_5 flex-col">
            <div class="group_6 flex-col">
              <div class="text-wrapper_14 flex-col"><span class="text_20">KUCOIN</span></div>
              <span class="paragraph_2">
                SHIBA&nbsp;INU&nbsp;(SHIB)&nbsp;GETS&nbsp;LISTED&nbsp;
                <br />
                ON&nbsp;KuCoin.
              </span>
              <img
                class="image_3"
                referrerpolicy="no-referrer"
                src="./assets/img/SketchPng77f918ef99084cc785ba961bddeb830d58c38d838ae22dbe4110bb41111a6a65.png"
              />
            </div>
          </div>
          <div class="group_7 flex-col">
            <div class="box_6 flex-col">
              <span class="text_21">IOST锁仓赚币</span>
              <span class="text_22">瓜分3.5万HUSD奖池</span>
              <img
                class="image_4"
                referrerpolicy="no-referrer"
                src="./assets/img/SketchPngb3969ead73a1a8e958c6dbbb1c3a663db5c214c6579de01af919bbdf9a457721.png"
              />
            </div>
          </div>
          <div class="group_8 flex-col">
            <div class="section_1 flex-col">
              <div class="block_59 flex-row">
                <div class="text-wrapper_15 flex-col"><span class="text_23">20TH&nbsp;session</span></div>
                <span class="text_24">Kickstarter</span>
                <span class="text_25">BHO</span>
              </div>
              <div class="text-wrapper_130 flex-row">
                <span class="text_26">Vote&nbsp;for&nbsp;a&nbsp;listing,&nbsp;win&nbsp;free&nbsp;airdrops!</span>
              </div>
              <div class="text-wrapper_131 flex-row"><span class="text_27">Featured&nbsp;Project</span></div>
              <div class="text-wrapper_132 flex-row justify-between">
                <span class="text_28">BHO</span>
                <span class="text_29">888,888</span>
              </div>
            </div>
          </div>
        </div>
        <div class="section_62 flex-row">
          <span class="text_30">100万“群星计划”数据看板</span>
          <div class="box_7 flex-row">
            <img
              class="label_3"
              referrerpolicy="no-referrer"
              src="./assets/img/SketchPng4169280de320fa5106381a576495e148d0790ee948b403ce622d4eaf09aaf0c8.png"
            />
            <span class="text_31">微信社群</span>
          </div>
          <div class="box_8 flex-row">
            <img
              class="label_4"
              referrerpolicy="no-referrer"
              src="./assets/img/SketchPngdeb4314dae9b16bdef4e70ed855c294ec319560d3e2b3484c9da7e50b53d718a.png"
            />
            <span class="text_32">TG社群</span>
          </div>
          <div class="box_9 flex-row">
            <img
              class="label_5"
              referrerpolicy="no-referrer"
              src="./assets/img/SketchPng5b3e6bf825520777ffd2bf6e18b76026d6b05638ed3135ea2d68f2f5fa9ef577.png"
            />
            <span class="text_33">QQ社群</span>
          </div>
          <div class="box_10 flex-row justify-between">
            <div class="box_11 flex-col"></div>
            <span class="text_34">Twitter</span>
          </div>
          <div class="box_12 flex-row">
            <img
              class="label_6"
              referrerpolicy="no-referrer"
              src="./assets/img/SketchPng16435c75284141b535b25f0b8b047600dcd8b7200fec507b4091ec139faa5cbc.png"
            />
            <span class="text_35">领养</span>
          </div>
          <div class="box_13 flex-row">
            <img
              class="label_7"
              referrerpolicy="no-referrer"
              src="./assets/img/SketchPng48efd877c0c8da7cf6940f6ef72ff8b5514270988b5acc7159a64f7b4f364f64.png"
            />
            <span class="text_36">社区入驻</span>
          </div>
          <div class="box_14 flex-row">
            <img
              class="label_8"
              referrerpolicy="no-referrer"
              src="./assets/img/SketchPng4e7e9141f1569378508bf0ca98f74b6366763c683b011a42870e335a6b59bae5.png"
            />
            <span class="text_37">广告投放</span>
          </div>
        </div>
        <div class="section_63 flex-row justify-between">
          <div class="box_15 flex-col">
            <div class="image-text_82 flex-row justify-between">
              <img
                class="label_9"
                referrerpolicy="no-referrer"
                src="./assets/img/SketchPng783d2bf31248cdbe4b3f5f9a270415706745d3fd78f7c40a746b1922523d971c.png"
              />
              <span class="text-group_1">{{ t('aiAgent') }}</span>
            </div>
            <div class="group_12 flex-col"></div>
            <div class="group_13 flex-col">
              <div class="group_95 flex-row justify-between">
                <div class="group_14 flex-col">
                  <div class="box_17 flex-col">
                    <div class="section_64 flex-row justify-between">
                      <div class="text-wrapper_133 flex-col">
                        <span class="text_38">R</span>
                        <span class="text_39">E</span>
                        <span class="text_40">S</span>
                        <span class="text_41">U</span>
                        <span class="text_42">P</span>
                      </div>
                      <div class="text-wrapper_134 flex-col">
                        <span class="text_43">T</span>
                        <span class="text_44">W</span>
                        <span class="text_45">O</span>
                        <span class="text_46">R</span>
                        <span class="text_47">K</span>
                      </div>
                    </div>
                    <div class="section_65 flex-row"><div class="box_18 flex-col"></div></div>
                    <div class="text-wrapper_135 flex-row">
                      <span class="text_48">R</span>
                      <span class="text_49">A</span>
                      <span class="text_50">R</span>
                      <span class="text_51">E</span>
                      <span class="text_52">A</span>
                      <span class="text_53">R</span>
                    </div>
                  </div>
                  <img
                    class="image_5"
                    referrerpolicy="no-referrer"
                    src="./assets/img/SketchPngbf9db5e18646a626f2a54693a9c91df4a25edb202ef792f57c371924cf4725e6.png"
                  />
                </div>
                <div class="group_15 flex-col">
                  <div class="image-wrapper_1 flex-col">
                    <img
                      class="label_10"
                      referrerpolicy="no-referrer"
                      src="./assets/img/SketchPng9f2a65b4069c114d306cc57380daf0e56bea69a5fea3b1ad533f9585526dab9f.png"
                    />
                  </div>
                </div>
              </div>
              <div class="text-wrapper_136 flex-row justify-between">
                <span class="text_54">$</span>
                <span class="text_55">59035197/2020</span>
              </div>
              <div class="group_96 flex-row">
                <img
                  class="label_11"
                  referrerpolicy="no-referrer"
                  src="./assets/img/SketchPng5ea2687da6e62f49399f9e69fb994a8dc93b40223f2b92070511f637c129bc86.png"
                />
                <img
                  class="image_6"
                  referrerpolicy="no-referrer"
                  src="./assets/img/SketchPng196c7cba5e4eeae7c1290595aa2df27b6eee995a465efce271535783554de1c4.png"
                />
                <span class="text_56">总覆盖人数/已接入社区</span>
              </div>
              <div class="box_20 flex-col">
                <div class="text-wrapper_137 flex-row"><span class="text_57">RWA/DWA流量交易数据估值</span></div>
                <div class="group_97 flex-row justify-between">
                  <div class="text-wrapper_138 flex-col justify-between">
                    <span class="text_58">$30k</span>
                    <span class="text_59">$15k</span>
                    <span class="text_60">$0</span>
                  </div>
                  <div class="group_98 flex-col justify-between">
                    <div class="box_21 flex-row">
                      <div class="image-text_83 flex-row justify-between">
                        <img
                          class="thumbnail_2"
                          referrerpolicy="no-referrer"
                          src="./assets/img/SketchPng8c0f12e9e2df78086f994d775dd132184a2555d62aa73a7efcb7bb50bb4929eb.png"
                        />
                        <span class="text-group_2">+12.3%</span>
                      </div>
                    </div>
                    <div class="box_22 flex-col">
                      <div class="image-wrapper_2 flex-col">
                        <img
                          class="thumbnail_3"
                          referrerpolicy="no-referrer"
                          src="./assets/img/SketchPng985c1816230fc2b0b2d12c726d137916d1b7c427084054858a64a2a2b3e29293.png"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="group_99 flex-col justify-between">
            <div class="block_60 flex-row justify-between">
              <div class="block_44 flex-col">
                <div class="box_102 flex-row justify-between">
                  <div class="image-text_84 flex-row justify-between">
                    <img
                      class="label_44"
                      referrerpolicy="no-referrer"
                      src="./assets/img/SketchPngf3dc389db700312e5c91b4017122a8c5bfd94b8f599d0cb43d3471de3661f96c.png"
                    />
                    <span class="text-group_45">{{ t('communityActivity') }}</span>
                  </div>
                  <div class="section_40 flex-row">
                    <div
                      class="text-wrapper_87 flex-col"
                      :class="{ 'selected': communityActivityTab === 'active' }"
                      @click="switchCommunityActivityTab('active')"
                    >
                      <span class="text_234">{{ t('activeUsers') }}</span>
                    </div>
                    <span
                      class="text_235 tab-option"
                      :class="{ 'selected': communityActivityTab === 'traffic' }"
                      @click="switchCommunityActivityTab('traffic')"
                    >
                      {{ t('traffic') }}
                    </span>
                  </div>
                </div>
                <div class="box_103 flex-row justify-between">
                  <div class="group_100 flex-col justify-between">
                    <div class="text-wrapper_139 flex-row justify-between">
                      <span class="text_236 animated-number">{{ animatedCommunityActivityNumber1 }}</span>
                      <span class="text_237">{{ communityActivityTab === 'active' ? (currentLanguage === 'zh-CN' ? '个' : '') : (currentLanguage === 'zh-CN' ? '个' : '') }}</span>
                    </div>
                    <div class="text-wrapper_140 flex-row justify-between">
                      <span class="text_238">$</span>
                      <span class="text_239 animated-number">{{ animatedCommunityActivityNumber2 }}{{ communityActivityTab === 'active' ? (currentLanguage === 'zh-CN' ? '人次' : ' visits') : (currentLanguage === 'zh-CN' ? '次' : ' times') }}</span>
                    </div>
                  </div>
                  <img
                    class="image_27"
                    referrerpolicy="no-referrer"
                    src="./assets/img/SketchPngd76410150ea4a54f9b585e1c2c55edab584ae299df60a0da0665bc80f8965b90.png"
                  />
                </div>
                <img
                  class="image_28"
                  referrerpolicy="no-referrer"
                  src="./assets/img/SketchPngf69f42dad53ea29364d85a834252fc758c76ff154208b83363df923dcad55e26.png"
                />
                <div class="text-wrapper_141 flex-row">
                  <span class="text_240">Price&nbsp;per&nbsp;1&nbsp;BTC</span>
                  <span class="text_241">$</span>
                  <span class="text_242">43.419,20</span>
                </div>
              </div>
              <div class="block_45 flex-col">
                <div class="box_74 flex-row">
                  <div class="image-text_85 flex-row justify-between">
                    <img
                      class="label_45"
                      referrerpolicy="no-referrer"
                      src="./assets/img/SketchPng09597c5a90173111c6d3f749a1f2a6119ef905391868851208d2ef5778017849.png"
                    />
                    <span class="text-group_46">{{ t('communityVolume') }}</span>
                  </div>
                  <div class="group_74 flex-row">
                    <div
                      class="text-wrapper_91 flex-col"
                      :class="{ 'selected': communityVolumeTab === 'total' }"
                      @click="switchCommunityVolumeTab('total')"
                    >
                      <span class="text_243">{{ t('totalAmount') }}</span>
                    </div>
                    <span
                      class="text_244 tab-option"
                      :class="{ 'selected': communityVolumeTab === 'yesterday' }"
                      @click="switchCommunityVolumeTab('yesterday')"
                    >
                      {{ t('yesterday') }}
                    </span>
                  </div>
                </div>
                <div class="box_104 flex-row">
                  <div class="block_61 flex-col justify-between">
                    <span class="text_245 animated-number">{{ animatedCommunityVolumeNumber1 }}</span>
                    <div class="text-wrapper_142 flex-row justify-between">
                      <span class="text_246">$</span>
                      <span class="text_247 animated-number">{{ animatedCommunityVolumeNumber2 }}</span>
                    </div>
                  </div>
                  <span class="text_248 animated-number">{{ animatedCommunityVolumeNumber3 }}</span>
                  <img
                    class="image_29"
                    referrerpolicy="no-referrer"
                    src="./assets/img/SketchPngc407f73f0b7f40cfcf4c1752f660f3af43de2b86c2b70f76af1fb8fc1bb28cd6.png"
                  />
                </div>
                <img
                  class="image_30"
                  referrerpolicy="no-referrer"
                  src="./assets/img/SketchPngf69f42dad53ea29364d85a834252fc758c76ff154208b83363df923dcad55e26.png"
                />
                <div class="text-wrapper_143 flex-row">
                  <span class="text_249">Price&nbsp;per&nbsp;1&nbsp;ETH</span>
                  <span class="text_250">$</span>
                  <span class="text_251">2.279,63</span>
                </div>
              </div>
              <div class="block_46 flex-col">
                <div class="section_41 flex-row">
                  <div class="image-text_86 flex-row justify-between">
                    <img
                      class="label_46"
                      referrerpolicy="no-referrer"
                      src="./assets/img/SketchPngc0270809502d793d150502d64b2d936ec49953e4e647cfb25693d6f25186205d.png"
                    />
                    <span class="text-group_47">{{ t('rewardDistributed') }}</span>
                  </div>
                  <div class="text-wrapper_94 flex-col"><span class="text_252">总计</span></div>
                </div>
                <div class="text-wrapper_144 flex-row justify-between">
                  <span class="text_253">43,00</span>
                  <span class="text_254">XING</span>
                </div>
                <div class="text-wrapper_145 flex-row justify-between">
                  <span class="text_255">T</span>
                  <span class="text_256">202651287120012</span>
                </div>
                <img
                  class="image_31"
                  referrerpolicy="no-referrer"
                  src="./assets/img/SketchPng15efe29033803e6b869373b8c73bfc502c85a0ffc7cb1c9665a1431e441f88ff.png"
                />
                <div class="text-wrapper_146 flex-row">
                  <span class="text_257">Price&nbsp;per&nbsp;1&nbsp;XING</span>
                  <span class="text_258">$</span>
                  <span class="text_259">0,00</span>
                </div>
              </div>
            </div>
            <div class="block_62 flex-row justify-between">
              <div class="section_42 flex-col">
                <div class="block_63 flex-row">
                  <img
                    class="label_47"
                    referrerpolicy="no-referrer"
                    src="./assets/img/SketchPng1a6587281fd5ff900127711527e4992820360231b3889af53a82d88dab539e3f.png"
                  />
                  <span class="text_260">{{ t('starPlanGrowth') }}</span>
                  <div class="box_77 flex-row">
                    <div class="image-text_87 flex-row justify-between">
                      <span class="text-group_48">This&nbsp;Month</span>
                      <img
                        class="thumbnail_84"
                        referrerpolicy="no-referrer"
                        src="./assets/img/SketchPng0d58fda905091a9414dee53ddb99b4d8a938f53d97027253c072d53101a4c9d4.png"
                      />
                    </div>
                  </div>
                </div>
                <div class="block_64 flex-row justify-between">
                  <span class="text_261">Balance</span>
                  <img
                    class="image_32"
                    referrerpolicy="no-referrer"
                    src="./assets/img/SketchPngf474b34f7174d44142d77ac6c211c11a5ebbee414042b109b3f368e88f07479a.png"
                  />
                </div>
                <div class="block_65 flex-row justify-between">
                  <div class="section_46 flex-row">
                    <img
                      class="thumbnail_85"
                      referrerpolicy="no-referrer"
                      src="./assets/img/SketchPng8c0f12e9e2df78086f994d775dd132184a2555d62aa73a7efcb7bb50bb4929eb.png"
                    />
                    <span class="text_262">+12.3%</span>
                  </div>
                  <img
                    class="image_33"
                    referrerpolicy="no-referrer"
                    src="./assets/img/SketchPng8d6f85d3168e90b724b91f90909092d6fb2b86aafb9c99071e887d7b9caa17a7.png"
                  />
                </div>
                <div class="block_66 flex-row justify-between">
                  <div class="box_78 flex-row justify-center">
                    <div class="image-text_88 flex-row justify-between">
                      <img
                        class="thumbnail_86"
                        referrerpolicy="no-referrer"
                        src="./assets/img/SketchPngb60505e06892052336e0013a0de1febe162332b34b4123bd04de7fc3852451ea.png"
                      />
                      <span class="text-group_49">新增流量</span>
                    </div>
                  </div>
                  <img
                    class="image_34"
                    referrerpolicy="no-referrer"
                    src="./assets/img/SketchPngd2f38cd3204a03a0bd62810f16e1aef95128082d61311aef1807c935fe83aca9.png"
                  />
                </div>
                <div class="text-wrapper_147 flex-row justify-between">
                  <span class="text_263">Week&nbsp;1</span>
                  <span class="text_264">Week&nbsp;2</span>
                  <span class="text_265">Week&nbsp;3</span>
                  <span class="text_266">Week&nbsp;4</span>
                </div>
                <div class="text-wrapper_148 flex-row justify-between">
                  <span class="text_267">$</span>
                  <span class="text_268">231,238.21</span>
                </div>
                <div class="block_67 flex-row justify-between">
                  <div class="box_105 flex-row">
                    <div class="image-text_89 flex-row justify-between">
                      <img
                        class="thumbnail_87"
                        referrerpolicy="no-referrer"
                        src="./assets/img/SketchPnga9f3f1773d077635abbc36266b25dd5d4ac4c805e28c98fb05d2ca55a9907d90.png"
                      />
                      <div class="text-group_67 flex-col justify-between">
                        <span class="text_269">收入曲线</span>
                        <span class="text_270">活跃值</span>
                      </div>
                    </div>
                    <div class="image-text_90 flex-row justify-between">
                      <img
                        class="thumbnail_88"
                        referrerpolicy="no-referrer"
                        src="./assets/img/SketchPng7a1a99144b0d4024426b5c7092d3e12532fae037be9cf14a7c64b63ef8f76c52.png"
                      />
                      <div class="text-group_68 flex-col justify-between">
                        <span class="text_269">收入曲线</span>
                        <span class="text_270">活跃值</span>
                      </div>
                    </div>
                  </div>
                  <div class="box_106 flex-col justify-between">
                    <img
                      class="image_35"
                      referrerpolicy="no-referrer"
                      src="./assets/img/SketchPng9c6decacb847f483a13dc4cc525a5ebbe92742a404371caeb3a79c0dac4fcfe4.png"
                    />
                    <div class="section_49 flex-col"></div>
                  </div>
                </div>
                <img
                  class="image_36"
                  referrerpolicy="no-referrer"
                  src="./assets/img/SketchPngd2f38cd3204a03a0bd62810f16e1aef95128082d61311aef1807c935fe83aca9.png"
                />
                <div class="image-wrapper_48 flex-col">
                  <img
                    class="image_37"
                    referrerpolicy="no-referrer"
                    src="./assets/img/SketchPnge807d3d1415d0c51925cb18e2034117469f9d052d349018a5dbb93fa1fbdc139.png"
                  />
                </div>
                <img
                  class="image_38"
                  referrerpolicy="no-referrer"
                  src="./assets/img/SketchPngbc45e3890b58ef444e93de2e2d1fed0e35c57db11ca127cc8835fcf403cab27f.png"
                />
              </div>
              <div class="group_25 flex-col">
                <span class="text_98">{{ t('premiumFeatures') }}</span>
                <div class="block_7 flex-col">
                  <span class="text_99">
                    {{ t('premiumDescription') }}
                  </span>
                  <div class="text-wrapper_38 flex-col">
                    <span class="text_100">{{ t('seeMoreFeatures') }}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="box_107 flex-col">
        <div class="group_101 flex-row justify-between">
          <div class="box_108 flex-row justify-between">
            <div class="text-wrapper_149 flex-col"><span class="text_271">全部公链</span></div>
            <div class="list_9 flex-row">
              <div
                class="image-text_91 flex-row justify-between"
                :style="{ background: item.lanhuBg0 }"
                v-for="(item, index) in loopData0"
                :key="index"
              >
                <img class="thumbnail_89" referrerpolicy="no-referrer" :src="item.lanhuimage0" />
                <span class="text-group_69" v-html="item.lanhutext0"></span>
              </div>
            </div>
          </div>
          <div class="box_109 flex-row">
            <span class="text_272">搜索</span>
            <img
              class="label_48"
              referrerpolicy="no-referrer"
              src="./assets/img/SketchPng52a3293a8098f555230305c71e842d40db4338857637cc1bc3946587eab3b467.png"
            />
          </div>
        </div>
        <div class="group_101 flex-row justify-between">
          <div class="text-wrapper_150 flex-col"><span class="text_273">全部社区</span></div>
          <div class="list_10 flex-row">
            <div
              class="image-text_92 flex-row"
              :style="{ background: item.lanhuBg0 }"
              v-for="(item, index) in loopData1"
              :key="index"
            >
              <img
                v-if="item.slot1 === 1"
                class="thumbnail_90"
                referrerpolicy="no-referrer"
                :src="item.specialSlot1.lanhuimage0"
              />
              <img
                v-if="item.slot2 === 2"
                class="thumbnail_91"
                referrerpolicy="no-referrer"
                src="./assets/img/SketchPng51253b9bb7071a7bccc3723ef64f4765a2a20a9a3da1d5da03a7980978db7d41.png"
              />
              <span class="text-group_70" v-html="item.lanhutext0"></span>
            </div>
          </div>
        </div>
        <div class="group_101 flex-row justify-between">
          <div class="text-wrapper_151 flex-col"><span class="text_274">全部地区</span></div>
          <div class="list_11 flex-row">
            <div
              class="image-text_93 flex-row"
              :style="{ background: item.lanhuBg0 }"
              v-for="(item, index) in loopData2"
              :key="index"
            >
              <img class="thumbnail_92" referrerpolicy="no-referrer" :src="item.lanhuimage0" />
              <span class="text-group_71" v-html="item.lanhutext0"></span>
            </div>
          </div>
        </div>
        <div class="group_104 flex-row">
          <div class="image-text_94 flex-row justify-between">
            <img
              class="thumbnail_93"
              referrerpolicy="no-referrer"
              src="./assets/img/SketchPng470e2d2430c126d803442377b72d5ac2abcdcac681c68e41f0814a3c75c13f68.png"
            />
            <div class="text-group_72">
              <span class="text_275">按热度排名</span>
              <span class="text_276"></span>
            </div>
          </div>
          <div class="image-text_95 flex-row justify-between">
            <img
              class="thumbnail_94"
              referrerpolicy="no-referrer"
              src="./assets/img/SketchPng7acc48bb08f97d8c44e4c97d1cc0248f0d4c3862b3c7c85ec38295d72333751e.png"
            />
            <span class="text-group_73">按人数排名</span>
          </div>
          <div class="image-text_96 flex-row justify-between">
            <img
              class="thumbnail_95"
              referrerpolicy="no-referrer"
              src="./assets/img/SketchPng4d52f24c46f194db03dd11f73019d6c75af74ca7b8a9c3e1e5bcc5707beebb36.png"
            />
            <span class="text-group_74">按成交额排名</span>
          </div>
          <div class="box_110 flex-row justify-between">
            <span class="text_277">社区平台</span>
            <img
              class="thumbnail_96"
              referrerpolicy="no-referrer"
              src="./assets/img/SketchPngbf857797cfa2c6a25b17a51525e810150a1b68ee6e49b1db87bdefad10379cca.png"
            />
          </div>
          <div class="box_111 flex-row justify-between">
            <span class="text_278">社区分类</span>
            <img
              class="thumbnail_97"
              referrerpolicy="no-referrer"
              src="./assets/img/SketchPng5c18299e5ab8ca9063015753319ad6e968e6cba3780cebfe70d0c1de22318ab4.png"
            />
          </div>
          <div class="box_112 flex-row justify-between">
            <span class="text_279">全部地区</span>
            <img
              class="thumbnail_98"
              referrerpolicy="no-referrer"
              src="./assets/img/SketchPng5c18299e5ab8ca9063015753319ad6e968e6cba3780cebfe70d0c1de22318ab4.png"
            />
          </div>
        </div>

        <div class="grid_1 flex-row">

          <div
              class="section_66 flex-col"
              v-for="(item, index) in data.data"
              :key="index"
          >
            <!-- 顶部信息 -->
            <div class="section_67 flex-row">
              <div class="group_123 flex-col">
                <div class="image-wrapper_61 flex-col">
                  <img
                      class="thumbnail_118"
                      referrerpolicy="no-referrer"
                      src="./assets/img/SketchPng527266c06970304632275b129e3bc551ff5a80e9880c777e36ed91f0eb529d13.png"
                  />
                </div>
              </div>

              <div class="group_124 flex-col justify-between">
                <div class="text-wrapper_160 flex-row justify-between">
                  <!-- 群名 -->
                  <span class="text_card_1">{{ item.vx_qunname }}</span>
                  <!-- 群人数 -->
                  <span class="text_316">({{ item.vx_qunrs }}人)</span>
                </div>
                <div class="text-wrapper_161 flex-row justify-between">
                  <span class="text_317">{{ t('activeDaily') }}：{{ item.hyd }}{{ t('people') }}</span>
                  <span class="text_318">{{ item.msg_count }}{{ t('messages') }}</span>
                </div>
              </div>

              <img
                  class="label_57"
                  referrerpolicy="no-referrer"
                  src="./assets/img/SketchPng26d24569117b92d4bd5f00454a80f71112a75f9ce6af7a71bbd065120c52b4ca.png"
              />
            </div>

            <!-- 标签 -->
            <span class="text_319">#Meme&nbsp;&nbsp;&nbsp;#土狗&nbsp;&nbsp;#sol</span>

            <!-- 估值 / 流量值 -->
            <div class="section_68 flex-row">
              <img
                  class="thumbnail_119"
                  referrerpolicy="no-referrer"
                  src="./assets/img/SketchPng0c8b48300b9dc67c9161f98e5d4cfd0f81f0800c06efd0e0226244743d48accb.png"
              />
              <div class="image-text_106 flex-row">
                <div class="text-group_84 flex-row justify-between">
                  <span class="text_320">{{ t('valuation') }}:&nbsp;{{ item.jcz }}&nbsp;XING</span>
                  <span class="text_321">+1.24%</span>
                </div>
                <img
                    class="thumbnail_120"
                    referrerpolicy="no-referrer"
                    src="./assets/img/SketchPng962a8d97efe2c084da17c44dcb39175edaa8a11074b19f760d6d6d20202c699f.png"
                />
              </div>
              <span class="text_322">{{ t('trafficValue') }}:{{ item.msg_factor }}</span>
            </div>

            <!-- 底部功能按钮 -->
            <div class="section_69 flex-row justify-between">
              <div class="image-text_107 flex-row justify-between">
                <img
                    class="label_58"
                    referrerpolicy="no-referrer"
                    src="./assets/img/SketchPngf0b54efe2ace70204380cdbc94b922a3c0757eae4bce35908b7cee7fc28924c2.png"
                />
                <span class="text-group_85">广告和空投投放</span>
              </div>
              <div class="section_70 flex-row">
                <div class="image-text_108 flex-row justify-between">
                  <img
                      class="label_59"
                      referrerpolicy="no-referrer"
                      src="./assets/img/SketchPng249b7186377e75b92373958e7d597bc0b7e5251f43f182a70b8e5b15fc40bf27.png"
                  />
                  <span class="text-group_86">连接</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="box_143 flex-col">
        <div style="text-align: center;">
          <span class="text_217">优质</span>
          <span class="text_218">Web3</span>
          <span class="text_219">合作项目</span>
        </div>
        <div class="list_12 flex-row">
          <div class="list-items_1 flex-col" v-for="(item, index) in loopData3" :key="index">
            <div class="group_140 flex-row justify-between">
              <div class="image-text_123 flex-row justify-between">
                <div class="block_35 flex-col" :style="{ background: item.lanhuBg3 }"></div>
                <div class="text-group_101 flex-col justify-between">
                  <span class="text_220" v-html="item.lanhutext0"></span>
                  <span class="text_221" v-html="item.lanhutext1"></span>
                </div>
              </div>
              <div class="image-text_124 flex-col justify-between">
                <img class="image_19" referrerpolicy="no-referrer" :src="item.lanhuimage0" />
                <span class="text-group_42" v-html="item.lanhutext2"></span>
              </div>
            </div>
            <div class="group_58 flex-row justify-between">
              <div class="text-group_101 flex-col justify-between">
                <span class="text_222" v-html="item.lanhutext3"></span>
                <span class="text_223" v-html="item.lanhutext4"></span>
              </div>
              <div class="text-wrapper_67 flex-col"><span class="text_224" v-html="item.lanhutext5"></span></div>
            </div>
          </div>
        </div>

        <div style="margin-bottom: 30px" class="group_101 flex-col">
          <div class="box_144 flex-row">
            <div class="image-wrapper_40 flex-col">
              <img
                class="image_20"
                referrerpolicy="no-referrer"
                src="./assets/img/SketchPng2a64a395aef78320ece8e71ed3002830cc6c897b3db7066d3730a74d3a8eaf66.png"
              />
            </div>
            <div class="image-wrapper_41 flex-col">
              <img
                class="image_21"
                referrerpolicy="no-referrer"
                src="./assets/img/SketchPngf05d2f57b6728318f090c20089b201bc52f6abfde5678eb1866e62e53e331f74.png"
              />
            </div>
            <div class="image-wrapper_42 flex-col">
              <img
                class="image_22"
                referrerpolicy="no-referrer"
                src="./assets/img/SketchPng07724f541ff49fae8a23f32ad0a02d548f482042e081467c9b8a36a5c8f1564e.png"
              />
            </div>
            <div class="image-wrapper_43 flex-col">
              <img
                class="image_23"
                referrerpolicy="no-referrer"
                src="./assets/img/SketchPngdfcd4853b247073d2544c7b9b43f57e9eade1d810465ce5f5cf793064cb9f127.png"
              />
            </div>
            <div class="image-wrapper_44 flex-col">
              <img
                class="image_24"
                referrerpolicy="no-referrer"
                src="./assets/img/SketchPngddc803406b0aa98453fb7ee569aecb10c1dbe903af75d2975d184e38aa5a0f06.png"
              />
            </div>
            <div class="image-wrapper_45 flex-col">
              <img
                class="image_25"
                referrerpolicy="no-referrer"
                src="./assets/img/SketchPng25b06e5fa1f367a2fd3c04dd773d64aadaf21ac8a3467b310404f0820495af50.png"
              />
            </div>
          </div>
        </div>
        <div class="group_101 flex-col justify-end">
          <div class="image-wrapper_83 flex-row">
            <img
              class="label_43"
              referrerpolicy="no-referrer"
              src="./assets/img/SketchPng3e38e94460505cc6b5205cbc02457186783a93d04bef33e43ddf9cb3e5edb374.png"
            />
          </div>
          <div class="box_145 flex-row">
            <div class="group_141 flex-col">
              <div class="text-wrapper_176 flex-row justify-between">
                <span class="text_225">XTrade</span>
                <span class="text_226">•</span>
              </div>
              <div class="text-wrapper_69">
                <span class="paragraph_3">
                  Address:&nbsp;1234&nbsp;Fashion&nbsp;Street,&nbsp;Suite&nbsp;567,New&nbsp;York,&nbsp;NY
                  <br />
                  Email:&nbsp;info&#64;fashionshop.com
                  <br />
                  Phone:(212)555-1234
                  <br />
                </span>
                <span class="text_227">Get&nbsp;direction</span>
              </div>
              <div class="image-wrapper_84 flex-row justify-between">
                <img
                  class="thumbnail_80"
                  referrerpolicy="no-referrer"
                  src="./assets/img/SketchPng837658bc409af72b6e102936e76c4143d0194261f17df8e088646b0c8b6e0b32.png"
                />
                <img
                  class="thumbnail_81"
                  referrerpolicy="no-referrer"
                  src="./assets/img/SketchPng325373f2cb2e0668e3e03a5535b23cc36aa345164494c6ae98e76ce4654ec691.png"
                />
                <img
                  class="thumbnail_82"
                  referrerpolicy="no-referrer"
                  src="./assets/img/SketchPng98bdc523a7e483e558c2703cabfe03af005b5b5ea8eabda430b0aa79b87f5da7.png"
                />
                <img
                  class="thumbnail_83"
                  referrerpolicy="no-referrer"
                  src="./assets/img/SketchPnge2badec4e155d55a245c5776387a8f88332e6c12623976686ac8553aee442f70.png"
                />
              </div>
            </div>
            <div class="group_142 flex-col justify-between">
              <div class="text-wrapper_70 flex-col"><span class="text_228">Help</span></div>
              <span class="paragraph_4">
                Privacy&nbsp;Policy
                <br />
                Returns&nbsp;+&nbsp;Exchanges
                <br />
                Shipping
                <br />
                Terms&nbsp;&amp;&nbsp;Conditions
                <br />
                FAO's
                <br />
                Compare&nbsp;Products
                <br />
                My&nbsp;Wishlist
              </span>
            </div>
            <div class="group_64 flex-row">
              <div class="text-group_101 flex-col justify-between">
                <span class="text_229">Useful&nbsp;Links</span>
                <span class="paragraph_5">
                  Our&nbsp;Store
                  <br />
                  Visit&nbsp;Our&nbsp;Store
                  <br />
                  Contact&nbsp;Us
                  <br />
                  About&nbsp;Us
                  <br />
                  Account
                </span>
              </div>
            </div>
            <div class="group_143 flex-col">
              <div class="text-wrapper_71 flex-col"><span class="text_230">Sign&nbsp;Up&nbsp;for&nbsp;Email</span></div>
              <span class="text_231">
                Sign&nbsp;up&nbsp;to&nbsp;get&nbsp;first&nbsp;dibs&nbsp;on&nbsp;new&nbsp;arrivals,&nbsp;sales,&nbsp;exclusive&nbsp;content,&nbsp;events&nbsp;and&nbsp;more!
              </span>
              <div class="box_71 flex-row">
                <span class="text_232">Your&nbsp;email&nbsp;address</span>
                <div class="text-wrapper_72 flex-col"><span class="text_233">Subscribe</span></div>
              </div>
              <img
                class="image_26"
                referrerpolicy="no-referrer"
                src="./assets/img/SketchPng8ebd50fec10de3f0d8dfc10e1dc37e660b95722b162ba6d99e94c4fb93ea9475.png"
              />
            </div>
          </div>
          <div class="text-wrapper_177 flex-row">
            <span class="paragraph_6">
              Copyright&nbsp;©&nbsp;2025&nbsp;MLK.&nbsp;All&nbsp;Right&nbsp;Reserved
              <br />
            </span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import NavigationMenu from '@/components/NavigationMenu.vue';
import { getTranslation, getCurrentLanguage } from '@/utils/translations.js';

export default {
  components: {
    NavigationMenu
  },
  data() {
    return {
      currentLanguage: getCurrentLanguage(),
      communityActivityTab: 'active',
      communityVolumeTab: 'total',

      // Community Activity Data
      communityActivityData: {
        active: { num1: 3132, num2: 5903510 },
        traffic: { num1: 2845, num2: 4567832 }
      },

      // Community Volume Data
      communityVolumeData: {
        total: { num1: 1202560, num2: 1202560, num3: 12 },
        yesterday: { num1: 85432, num2: 85432, num3: 8 }
      },

      // Animated numbers
      animatedCommunityActivityNumber1: 3132,
      animatedCommunityActivityNumber2: 5903510,
      animatedCommunityVolumeNumber1: 1202560,
      animatedCommunityVolumeNumber2: 1202560,
      animatedCommunityVolumeNumber3: 12,

      loopData0: [
        {
          lanhuBg0: 'transparent',
          lanhuimage0:
            'https://lanhu-oss-2537-2.lanhuapp.com/SketchPng0420867cd86e335e06e327ecdf1608acfb6b0b31b158acac16f95719e44e8a89',
          lanhutext0: 'BSC'
        },
        {
          lanhuBg0: 'rgba(255,255,255,1.000000)',
          lanhuimage0:
            'https://lanhu-oss-2537-2.lanhuapp.com/SketchPngce66f2e70b69d6bc4b2e64683a0ee427ffc0a2c075cfcf3f109810c1d3579f74',
          lanhutext0: 'SOL'
        },
        {
          lanhuBg0: 'transparent',
          lanhuimage0:
            'https://lanhu-oss-2537-2.lanhuapp.com/SketchPng511678aacb4aa2ef2ceb764ee633cc6b9974eefa62d7d3c31c9172c1f5814801',
          lanhutext0: 'ETH'
        },
        {
          lanhuBg0: 'transparent',
          lanhuimage0:
            'https://lanhu-oss-2537-2.lanhuapp.com/SketchPng0fcea56b94593aa90fd4ae53c964172d29f072a4915a9c41923dbd6bc666ab93',
          lanhutext0: 'BASE'
        },
        {
          lanhuBg0: 'transparent',
          lanhuimage0:
            'https://lanhu-oss-2537-2.lanhuapp.com/SketchPngb1ad3b45ed9450022315a6ee5c64e105d4370fcb83976efc565d26a58cb96aae',
          lanhutext0: 'TRON'
        },
        {
          lanhuBg0: 'transparent',
          lanhuimage0:
            'https://lanhu-oss-2537-2.lanhuapp.com/SketchPng0ab1adf8a10cc78012e50f9dde63bda44d480360bc5f1e76774211316c255c5e',
          lanhutext0: 'OP'
        },
        {
          lanhuBg0: 'transparent',
          lanhuimage0:
            'https://lanhu-oss-2537-2.lanhuapp.com/SketchPng184210a3733da2f07a44c079f81b3e1087f3213e7212d2c58a41d47ebf87f3b6',
          lanhutext0: 'BTC'
        },
        {
          lanhuBg0: 'transparent',
          lanhuimage0:
            'https://lanhu-oss-2537-2.lanhuapp.com/SketchPngf04ecf623c36e713ab68886df3337d5f2aa528dc9d60a9c4a96720b3fec1592b',
          lanhutext0: 'AVA'
        }
      ],
      loopData1: [
        {
          lanhuBg0: 'transparent',
          lanhutext0: 'WEB3',
          specialSlot1: {
            lanhuimage0:
              'https://lanhu-oss-2537-2.lanhuapp.com/SketchPng0420867cd86e335e06e327ecdf1608acfb6b0b31b158acac16f95719e44e8a89'
          },
          slot1: 1
        },
        {
          lanhuBg0: 'rgba(255,255,255,1.000000)',
          lanhutext0: 'MEME',
          specialSlot1: {
            lanhuimage0:
              'https://lanhu-oss-2537-2.lanhuapp.com/SketchPng8bf753ba535b752cbd92254cc4b195c7269f5a92dfa3fc5459095ccec05d628b'
          },
          slot1: 1
        },
        {
          lanhuBg0: 'transparent',
          lanhutext0: 'RWA',
          specialSlot1: {
            lanhuimage0:
              'https://lanhu-oss-2537-2.lanhuapp.com/SketchPng31f1d50bb4864420b4a2c4682b82ea4920678be3914190424dadff78615af5fc'
          },
          slot1: 1
        },
        {
          lanhuBg0: 'transparent',
          lanhutext0: 'NFT',
          specialSlot1: {
            lanhuimage0:
              'https://lanhu-oss-2537-2.lanhuapp.com/SketchPng400d492fc46b336bf6c4db95cad19343a0f7c241b9b812aded3b1da30916a6c7'
          },
          slot1: 1
        },
        {
          lanhuBg0: 'transparent',
          lanhutext0: 'Project',
          specialSlot1: {
            lanhuimage0:
              'https://lanhu-oss-2537-2.lanhuapp.com/SketchPng71cf4c37a3db6e134bd5cc84e55a4b13c4ce1b244961c4a08ce6af4d3dafb7e3'
          },
          slot1: 1
        },
        {
          lanhuBg0: 'transparent',
          lanhutext0: '合约',
          specialSlot1: {
            lanhuimage0:
              'https://lanhu-oss-2537-2.lanhuapp.com/SketchPngb57ce3b74079f562288701bd4087cb964e7ef5663756f08e39b2e62e35cf6be5'
          },
          slot1: 1
        },
        {
          lanhuBg0: 'transparent',
          lanhutext0: '吃瓜',
          specialSlot1: {
            lanhuimage0:
              'https://lanhu-oss-2537-2.lanhuapp.com/SketchPng1451ed848d1d9638318416d0d348af5cadc028b3385996903d1c6dc75a3f28ae'
          },
          slot1: 1
        },
        {
          lanhuBg0: 'transparent',
          lanhutext0: 'GameFi',
          specialSlot1: {
            lanhuimage0:
              'https://lanhu-oss-2537-2.lanhuapp.com/SketchPng7920131d1a0b90f8880965817540f65afd35f81b1b22d3c29f5bbbe72e566774'
          },
          slot1: 1
        },
        { lanhuBg0: 'transparent', lanhutext0: '会议/活动', slot2: 2 }
      ],
      loopData2: [
        {
          lanhuBg0: 'transparent',
          lanhuimage0:
            'https://lanhu-oss-2537-2.lanhuapp.com/SketchPng0420867cd86e335e06e327ecdf1608acfb6b0b31b158acac16f95719e44e8a89',
          lanhutext0: '亚洲'
        },
        {
          lanhuBg0: 'rgba(255,255,255,1.000000)',
          lanhuimage0:
            'https://lanhu-oss-2537-2.lanhuapp.com/SketchPng3683dcb2ce1f40d893ee8d3540c9e39461e9805a30d0f5a4b05c08281fc2a314',
          lanhutext0: '香港'
        },
        {
          lanhuBg0: 'transparent',
          lanhuimage0:
            'https://lanhu-oss-2537-2.lanhuapp.com/SketchPnge722ae877a3973f70f4f03a2589c2403adfb76675368de17866346e81d4080b2',
          lanhutext0: '日本'
        },
        {
          lanhuBg0: 'transparent',
          lanhuimage0:
            'https://lanhu-oss-2537-2.lanhuapp.com/SketchPngd343f1eef047fb0ba80a85eb293d7868edbb450d3985a840970f48ab4802730e',
          lanhutext0: '泰国'
        },
        {
          lanhuBg0: 'transparent',
          lanhuimage0:
            'https://lanhu-oss-2537-2.lanhuapp.com/SketchPngb18ae525689dc8f5c2553cd53b3f10a878447302acd1054230cb545b6ae89b89',
          lanhutext0: '北美'
        },
        {
          lanhuBg0: 'transparent',
          lanhuimage0:
            'https://lanhu-oss-2537-2.lanhuapp.com/SketchPngc021de09598e5ba65b998929c426e4e3df7812dd427b1301dfffabec466e9b19',
          lanhutext0: '南非'
        },
        {
          lanhuBg0: 'transparent',
          lanhuimage0:
            'https://lanhu-oss-2537-2.lanhuapp.com/SketchPngf7cfe4a55a04e4c4ef0666b270674e8348d1fab9229521a202bcd4f56ca9107d',
          lanhutext0: '东欧'
        }
      ],
      loopData3: [
        {
          lanhuBg3:
            'url(https://lanhu-dds-backend.oss-cn-beijing.aliyuncs.com/merge_image/imgs/ace8fe0966794301b91ef00a7df142a3_mergeImage.png)',
          lanhutext0: 'Elympics',
          lanhutext1: '&#64;elympics_ai',
          lanhuimage0:
            'https://lanhu-oss-2537-2.lanhuapp.com/SketchPngb163ce479dccd085f845225e47a6903941b30dae5c9f8194131c1d1cf9910742',
          lanhutext2: '3.33K&nbsp;unique&nbsp;SNAPPERS',
          lanhutext3: 'Total&nbsp;Reward&nbsp;pool',
          lanhutext4: '$560K&nbsp;in&nbsp;$ELP',
          lanhutext5: 'View'
        },
        {
          lanhuBg3:
            'url(https://lanhu-dds-backend.oss-cn-beijing.aliyuncs.com/merge_image/imgs/547b72e09b96434bb90f36e787ee7de3_mergeImage.png)',
          lanhutext0: 'Recall',
          lanhutext1: '&#64;elympics_ai',
          lanhuimage0:
            'https://lanhu-oss-2537-2.lanhuapp.com/SketchPngb163ce479dccd085f845225e47a6903941b30dae5c9f8194131c1d1cf9910742',
          lanhutext2: '8.87K&nbsp;unique&nbsp;SNAPPERS',
          lanhutext3: 'Total&nbsp;Reward&nbsp;pool',
          lanhutext4: '0.5%&nbsp;of&nbsp;&nbsp;TOtal&nbsp;Token&nbsp;Supply',
          lanhutext5: 'View'
        },
        {
          lanhuBg3:
            'url(https://lanhu-dds-backend.oss-cn-beijing.aliyuncs.com/merge_image/imgs/851e461393d64891aee8f6c2fe140ff1_mergeImage.png)',
          lanhutext0: 'Elympics',
          lanhutext1: '&#64;elympics_ai',
          lanhuimage0:
            'https://lanhu-oss-2537-2.lanhuapp.com/SketchPngb163ce479dccd085f845225e47a6903941b30dae5c9f8194131c1d1cf9910742',
          lanhutext2: '3.33K&nbsp;unique&nbsp;SNAPPERS',
          lanhutext3: 'Total&nbsp;Reward&nbsp;pool',
          lanhutext4: '$560K&nbsp;in&nbsp;$ELP',
          lanhutext5: 'View'
        }
      ],
      constants: {},
      data: {
        data: [
          {
            vx_qunname: "加密货币投资交流群",
            vx_qunrs: 2456,
            hyd: 824,
            msg_count: 1520,
            jcz: 15800,
            msg_factor: 2.45
          },
          {
            vx_qunname: "DeFi协议研讨社区",
            vx_qunrs: 1892,
            hyd: 623,
            msg_count: 890,
            jcz: 12500,
            msg_factor: 1.98
          },
          {
            vx_qunname: "NFT艺术收藏家",
            vx_qunrs: 3201,
            hyd: 1056,
            msg_count: 2340,
            jcz: 28900,
            msg_factor: 3.12
          },
          {
            vx_qunname: "Web3开发者联盟",
            vx_qunrs: 1456,
            hyd: 487,
            msg_count: 756,
            jcz: 9800,
            msg_factor: 1.67
          },
          {
            vx_qunname: "区块链新手学习群",
            vx_qunrs: 5642,
            hyd: 1789,
            msg_count: 4230,
            jcz: 45600,
            msg_factor: 4.25
          },
          {
            vx_qunname: "MEME币讨论社区",
            vx_qunrs: 2890,
            hyd: 934,
            msg_count: 1876,
            jcz: 18700,
            msg_factor: 2.89
          }
        ]
      }
    };
  },
  computed: {
    t() {
      return (key) => getTranslation(key, this.currentLanguage);
    }
  },
  methods: {
    handleNavigation(item) {
      console.log('导航到:', item);
      // 这里可以添加路由跳转逻辑
      if (item.href) {
        if (item.href.startsWith('http')) {
          window.open(item.href, '_blank');
        } else {
          this.$router.push(item.href);
        }
      }
    },

    handleLanguageChange(language) {
      console.log('语言切换到:', language);
      this.currentLanguage = language.code;

      // 更新页面内容
      this.updatePageLanguage(language);

      // 强制更新组件
      this.$forceUpdate();
    },

    handleSearchQuery(query) {
      console.log('搜索查询:', query);
      // 这里可以添加搜索功能
      // 例如：过滤数据或发送搜索请求
    },

    updatePageLanguage(language) {
      // 根��语言代码更新页面内容
      // 这只是一个示例，实际项目中应该使用i18n库
      document.documentElement.lang = language.code;
    },

    switchCommunityActivityTab(tab) {
      if (this.communityActivityTab === tab) return;

      this.communityActivityTab = tab;
      const targetData = this.communityActivityData[tab];

      this.animateNumber('animatedCommunityActivityNumber1', targetData.num1);
      this.animateNumber('animatedCommunityActivityNumber2', targetData.num2);
    },

    switchCommunityVolumeTab(tab) {
      if (this.communityVolumeTab === tab) return;

      this.communityVolumeTab = tab;
      const targetData = this.communityVolumeData[tab];

      this.animateNumber('animatedCommunityVolumeNumber1', targetData.num1);
      this.animateNumber('animatedCommunityVolumeNumber2', targetData.num2);
      this.animateNumber('animatedCommunityVolumeNumber3', targetData.num3);
    },

    animateNumber(property, targetValue) {
      const startValue = this[property];
      const startTime = Date.now();
      const duration = 500; // 0.5秒动画

      const animate = () => {
        const now = Date.now();
        const progress = Math.min((now - startTime) / duration, 1);

        // 使用缓动函数
        const easeProgress = 1 - Math.pow(1 - progress, 3);

        const currentValue = Math.round(startValue + (targetValue - startValue) * easeProgress);
        this[property] = currentValue;

        if (progress < 1) {
          requestAnimationFrame(animate);
        }
      };

      requestAnimationFrame(animate);
    },
    async getData() {
      try {
        const res = await fetch("/api/v1/sqzcs", {
          headers: {
            "accept": "application/json, text/plain, */*",
            "accept-language": "zh-CN,zh;q=0.9,en;q=0.8",
            "proxy-connection": "keep-alive",
            "Referrer-Policy": "strict-origin-when-cross-origin"
          },
          method: "GET"
        });

        const json = await res.json();
        this.data = json;
      } catch (err) {
        console.error('API请求失败，使用��拟数据：', err);
        // 保持现有的模拟数据
      }
    }
  },

  mounted() {
    this.getData();
    // Load saved language
    const saved = localStorage.getItem('selectedLanguage');
    if (saved) {
      try {
        const language = JSON.parse(saved);
        this.currentLanguage = language.code;
      } catch (e) {
        console.error('Failed to parse saved language:', e);
      }
    }
  }
};
</script>
<style scoped lang="css" src="./assets/index.css" />
